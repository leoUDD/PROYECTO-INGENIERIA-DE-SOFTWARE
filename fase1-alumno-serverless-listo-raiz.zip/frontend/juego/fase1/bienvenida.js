if (exigirSesionGrupo()) {
  const paginaActual = "bienvenida.html";
  let procesando = false;

  async function prepararPantalla() {
    try {
      const estado = await obtenerEstadoJuego();

      if (redirigirRutaSugerida(estado, paginaActual)) {
        return;
      }
    } catch (error) {
      mostrarErrorJuego(error);
    }

    const video = document.querySelector("video");

    if (video) {
      video.muted = true;
      video.play().catch(() => {});
    }

    const continuar =
      buscarElementoPorTexto("a, button", "continuar") ||
      document.querySelector("a[href]");

    if (!continuar) {
      return;
    }

    continuar.setAttribute("href", "#");

    continuar.addEventListener("click", async (evento) => {
      evento.preventDefault();

      if (procesando) {
        return;
      }

      procesando = true;
      continuar.setAttribute("aria-disabled", "true");

      try {
        const estado = await llamarApiJuego(
          "/api/fase1/iniciar",
          { method: "POST" },
        );

        window.location.href =
          estado.rutaSugerida || "modo-equipo.html";
      } catch (error) {
        procesando = false;
        continuar.removeAttribute("aria-disabled");
        mostrarErrorJuego(error);
      }
    });

    const activarSonido = buscarElementoPorTexto(
      "button, a, p, div",
      "activa el sonido",
    );

    activarSonido?.addEventListener("click", () => {
      if (!video) return;
      video.muted = false;
      video.volume = 1;
      video.play().catch(() => {});
    });
  }

  prepararPantalla();
}
