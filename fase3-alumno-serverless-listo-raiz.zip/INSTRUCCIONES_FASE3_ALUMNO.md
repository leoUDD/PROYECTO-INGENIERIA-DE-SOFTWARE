# Fase 3 — Creatividad y LEGO

El paquete agrega este flujo:

```text
Ranking Fase 2
→ Mapa de habilidades: Creatividad
→ Transición Creatividad
→ LEGO
→ Ranking Fase 3
→ Mapa de Misión Final
```

## Instalación

Desde la raíz del repositorio:

```bash
git add .
git commit -m "Respaldo antes de instalar Fase 3"

unzip -o fase3-alumno-serverless-listo-raiz.zip
python instalar_fase3_alumno.py
```

El contenido nuevo está dentro de `fase3_payload`, por lo que
el instalador no intenta copiar archivos sobre sí mismos.

## Reconstruir

```bash
cd backend-serverless

npm install
npm run verificar

rm -rf .aws-sam
export PATH="$PWD/node_modules/.bin:$PATH"
sam build
npm run local:api
```

No ejecutes `npm run local:preparar` si quieres conservar
las sesiones actuales.

## Rutas nuevas

```text
GET  /api/fase3/estado
POST /api/fase3/iniciar
POST /api/fase3/listo
POST /api/fase3/lego/completar
POST /api/fase3/ruleta/girar
POST /api/fase3/astronauta/responder
GET  /api/fase3/ranking
```

## Foto LEGO

Para las pruebas locales, la foto se reduce y guarda en
`localStorage`. DynamoDB guarda únicamente si el grupo continuó
con foto o sin foto.

En AWS, después debe reemplazarse por S3 con una URL prefirmada.

## Duración

La construcción LEGO dura 15 segundos. Se modifica en:

```text
backend-serverless/src/fase3/servicio.ts
```

```ts
export const DURACION_LEGO_SEGUNDOS = 15;
```
