#!/usr/bin/env python3
from pathlib import Path
import json
import re
import shutil
import sys

RAIZ = Path.cwd()
PAQUETE = (
    Path(__file__).resolve().parent
    / "fase3_payload"
)


def error(mensaje: str) -> None:
    print(
        f"ERROR: {mensaje}",
        file=sys.stderr,
    )
    raise SystemExit(1)


def copiar_arbol(
    origen: Path,
    destino: Path,
) -> None:
    if not origen.exists():
        return

    destino.mkdir(
        parents=True,
        exist_ok=True,
    )

    shutil.copytree(
        origen,
        destino,
        dirs_exist_ok=True,
    )


def copiar_payload() -> None:
    copiar_arbol(
        PAQUETE / "backend-serverless",
        RAIZ / "backend-serverless",
    )

    copiar_arbol(
        PAQUETE / "frontend",
        RAIZ / "frontend",
    )


def copiar_recursos_originales() -> None:
    origen = RAIZ / "juego" / "static"
    destino = (
        RAIZ
        / "frontend"
        / "compartido"
        / "recursos"
    )

    equivalencias = {
        "images": "imagenes",
        "sounds": "sonidos",
        "videos": "videos",
    }

    for original, nuevo in (
        equivalencias.items()
    ):
        ruta = origen / original

        if ruta.exists():
            copiar_arbol(
                ruta,
                destino / nuevo,
            )


def corregir_rutas_css(
    contenido: str,
) -> str:
    reemplazos = {
        "/static/images/":
            "../../compartido/recursos/imagenes/",
        "/static/sounds/":
            "../../compartido/recursos/sonidos/",
        "/static/videos/":
            "../../compartido/recursos/videos/",
        "../images/":
            "../../compartido/recursos/imagenes/",
        "../sounds/":
            "../../compartido/recursos/sonidos/",
        "../videos/":
            "../../compartido/recursos/videos/",
    }

    for anterior, nuevo in (
        reemplazos.items()
    ):
        contenido = contenido.replace(
            anterior,
            nuevo,
        )

    return contenido


def copiar_css_originales() -> None:
    origen = (
        RAIZ
        / "juego"
        / "static"
        / "css"
    )

    destino = (
        RAIZ
        / "frontend"
        / "juego"
        / "fase3"
    )

    destino.mkdir(
        parents=True,
        exist_ok=True,
    )

    nombres = [
        "estilo_transicioncreatividad.css",
        "estilo_lego.css",
        "estilo_ranking.css",
    ]

    for nombre in nombres:
        ruta = origen / nombre

        if not ruta.exists():
            print(
                f"AVISO: no se encontró {ruta}",
            )
            continue

        contenido = ruta.read_text(
            encoding="utf-8",
        )

        (
            destino / nombre
        ).write_text(
            corregir_rutas_css(
                contenido,
            ),
            encoding="utf-8",
        )


def crear_mapas() -> None:
    carpeta = (
        RAIZ
        / "frontend"
        / "juego"
        / "mapa"
    )

    origen = carpeta / "habilidades.html"

    if not origen.exists():
        error(
            "No se encontró frontend/juego/mapa/habilidades.html. "
            "Instala y prueba primero la Fase 2.",
        )

    base = origen.read_text(
        encoding="utf-8",
    )

    patron_config = re.compile(
        r"window\.MAPA_HABILIDADES_CONFIG"
        r"\s*=\s*\{.*?\};",
        re.S,
    )

    def construir(
        nombre: str,
        habilidad: str,
        completadas: list[str],
        texto_boton: str,
        script: str,
    ) -> None:
        contenido = base

        config = (
            "window.MAPA_HABILIDADES_CONFIG = {\n"
            f'  habilidadActiva: "{habilidad}",\n'
            "  habilidadesCompletadas: "
            + json.dumps(
                completadas,
                ensure_ascii=False,
            )
            + ",\n"
            '  rutaContinuar: "#",\n'
            f'  textoBoton: "{texto_boton}"\n'
            "};"
        )

        if patron_config.search(contenido):
            contenido = patron_config.sub(
                config,
                contenido,
                count=1,
            )
        else:
            contenido = contenido.replace(
                "</head>",
                (
                    "<script>\n"
                    + config
                    + "\n</script>\n</head>"
                ),
                1,
            )

        contenido = contenido.replace(
            "../fase2/fase2-comun.js",
            "../fase3/fase3-comun.js",
        )

        contenido = contenido.replace(
            'src="mapa-flujo.js"',
            f'src="{script}"',
        )

        contenido = contenido.replace(
            "CONTINUAR A DESAFÍOS",
            texto_boton,
        )

        (
            carpeta / nombre
        ).write_text(
            contenido,
            encoding="utf-8",
        )

    construir(
        "creatividad.html",
        "Creatividad",
        [
            "Trabajo en equipo",
            "Empatía",
        ],
        "CONTINUAR A CREATIVIDAD",
        "mapa-creatividad.js",
    )

    construir(
        "final.html",
        "Misión final",
        [
            "Trabajo en equipo",
            "Empatía",
            "Creatividad",
        ],
        "MISIÓN FINAL · PRÓXIMA FASE",
        "mapa-final.js",
    )


def parchear_template() -> None:
    ruta = (
        RAIZ
        / "backend-serverless"
        / "template.yaml"
    )

    if not ruta.exists():
        error(
            "No se encontró backend-serverless/template.yaml",
        )

    contenido = ruta.read_text(
        encoding="utf-8",
    )

    if "FuncionFase3:" in contenido:
        print(
            "template.yaml ya contiene FuncionFase3",
        )
        return

    bloque = '''
  FuncionFase3:
    Type: AWS::Serverless::Function
    Properties:
      CodeUri: .
      Handler: src/fase3/api.manejador
      Policies: *PermisosDynamo
      Events:
        ObtenerEstadoFase3:
          Type: HttpApi
          Properties:
            ApiId: !Ref ApiBackend
            Path: /api/fase3/estado
            Method: GET

        IniciarFase3:
          Type: HttpApi
          Properties:
            ApiId: !Ref ApiBackend
            Path: /api/fase3/iniciar
            Method: POST

        MarcarListoFase3:
          Type: HttpApi
          Properties:
            ApiId: !Ref ApiBackend
            Path: /api/fase3/listo
            Method: POST

        CompletarLegoFase3:
          Type: HttpApi
          Properties:
            ApiId: !Ref ApiBackend
            Path: /api/fase3/lego/completar
            Method: POST

        GirarRuletaFase3:
          Type: HttpApi
          Properties:
            ApiId: !Ref ApiBackend
            Path: /api/fase3/ruleta/girar
            Method: POST

        ResponderAstronautaFase3:
          Type: HttpApi
          Properties:
            ApiId: !Ref ApiBackend
            Path: /api/fase3/astronauta/responder
            Method: POST

        ObtenerRankingFase3:
          Type: HttpApi
          Properties:
            ApiId: !Ref ApiBackend
            Path: /api/fase3/ranking
            Method: GET
    Metadata:
      BuildMethod: esbuild
      BuildProperties: *ConfiguracionEsbuild

'''

    if "Outputs:" not in contenido:
        error(
            "No se encontró Outputs en template.yaml",
        )

    contenido = contenido.replace(
        "Outputs:\n",
        bloque + "Outputs:\n",
        1,
    )

    ruta.write_text(
        contenido,
        encoding="utf-8",
    )


def parchear_package_json() -> None:
    ruta = (
        RAIZ
        / "backend-serverless"
        / "package.json"
    )

    if not ruta.exists():
        return

    datos = json.loads(
        ruta.read_text(
            encoding="utf-8",
        ),
    )

    scripts = datos.setdefault(
        "scripts",
        {},
    )

    comando = scripts.get(
        "empaquetar:verificar",
        "",
    )

    if (
        comando and
        "src/fase3/api.ts" not in comando
    ):
        referencia = "src/fase2/api.ts"

        if referencia in comando:
            comando = comando.replace(
                referencia,
                (
                    referencia
                    + " src/fase3/api.ts"
                ),
            )
        else:
            comando += " src/fase3/api.ts"

        scripts[
            "empaquetar:verificar"
        ] = comando

    ruta.write_text(
        json.dumps(
            datos,
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def parchear_fase2_backend() -> None:
    ruta = (
        RAIZ
        / "backend-serverless"
        / "src"
        / "fase2"
        / "servicio.ts"
    )

    if not ruta.exists():
        error(
            "No se encontró el servicio de Fase 2",
        )

    contenido = ruta.read_text(
        encoding="utf-8",
    )

    bloque_viejo = '''  if (fase.startsWith("f3_") || fase === "mapa_f3_creatividad") {
    return "ranking.html";
  }'''

    bloque_nuevo = '''  if (fase === "mapa_f3_creatividad") {
    return "../mapa/creatividad.html";
  }

  if (fase === "f3_transicion_creatividad") {
    return "../fase3/transicion-creatividad.html";
  }

  if (fase === "f3_lego") {
    return "../fase3/lego.html";
  }

  if (fase === "f3_ranking") {
    return "../fase3/ranking.html";
  }

  if (fase === "mapa_f4_final" || fase.startsWith("f4_")) {
    return "../mapa/final.html";
  }'''

    if bloque_viejo in contenido:
        contenido = contenido.replace(
            bloque_viejo,
            bloque_nuevo,
            1,
        )
    elif (
        'fase === "mapa_f3_creatividad"'
        not in contenido
    ):
        marcador = '''  if (fase === "f2_ranking") {
    return "ranking.html";
  }'''

        if marcador in contenido:
            contenido = contenido.replace(
                marcador,
                marcador
                + "\n\n"
                + bloque_nuevo,
                1,
            )
        else:
            print(
                "AVISO: no se pudo ampliar rutaSugerida de Fase 2",
            )

    ruta.write_text(
        contenido,
        encoding="utf-8",
    )


def parchear_ranking_fase2() -> None:
    ruta = (
        RAIZ
        / "frontend"
        / "juego"
        / "fase2"
        / "ranking.html"
    )

    if not ruta.exists():
        error(
            "No se encontró el ranking de Fase 2",
        )

    contenido = ruta.read_text(
        encoding="utf-8",
    )

    if "btnContinuarFase3" in contenido:
        return

    panel = '''
    <section class="serverless-f3-ready">
      <button
        id="btnContinuarFase3"
        class="serverless-f3-button"
        type="button"
      >
        CONTINUAR A CREATIVIDAD
      </button>

      <div
        id="progresoInicioFase3"
        class="serverless-f3-progress"
      >
        0/0 grupos listos
      </div>
    </section>
'''

    if "</main>" in contenido:
        contenido = contenido.replace(
            "</main>",
            panel + "\n  </main>",
            1,
        )
    else:
        contenido = contenido.replace(
            "</body>",
            panel + "\n</body>",
            1,
        )

    if (
        "../fase3/fase3-serverless.css"
        not in contenido
    ):
        contenido = contenido.replace(
            "</head>",
            (
                '  <link rel="stylesheet" '
                'href="../fase3/fase3-serverless.css">\n'
                "</head>"
            ),
            1,
        )

    scripts = '''
  <script src="../fase3/fase3-comun.js"></script>
  <script src="../fase3/iniciar-desde-ranking.js"></script>
'''

    contenido = contenido.replace(
        "</body>",
        scripts + "\n</body>",
        1,
    )

    ruta.write_text(
        contenido,
        encoding="utf-8",
    )


def parchear_profesor() -> None:
    ruta = (
        RAIZ
        / "backend-serverless"
        / "src"
        / "profesor"
        / "servicio.ts"
    )

    if not ruta.exists():
        return

    contenido = ruta.read_text(
        encoding="utf-8",
    )

    contenido = contenido.replace(
        "f3_lego: 120,",
        "f3_lego: 15,",
    )

    ruta.write_text(
        contenido,
        encoding="utf-8",
    )


def main() -> None:
    if not (
        RAIZ / "backend-serverless"
    ).exists():
        error(
            "Ejecuta este instalador desde la raíz del repositorio",
        )

    if not PAQUETE.exists():
        error(
            "No se encontró fase3_payload. Descomprime el ZIP completo.",
        )

    copiar_payload()
    copiar_recursos_originales()
    copiar_css_originales()
    crear_mapas()
    parchear_template()
    parchear_package_json()
    parchear_fase2_backend()
    parchear_ranking_fase2()
    parchear_profesor()

    print()
    print(
        "Fase 3 instalada correctamente.",
    )
    print(
        "Flujo: Ranking F2 -> Mapa Creatividad -> "
        "Transición -> LEGO -> Ranking F3 -> Mapa Final",
    )
    print(
        "Ahora ejecuta: cd backend-serverless && "
        "npm run verificar && rm -rf .aws-sam && sam build",
    )


if __name__ == "__main__":
    main()
